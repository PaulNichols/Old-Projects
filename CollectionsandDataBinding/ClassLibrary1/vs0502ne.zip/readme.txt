.NET 2 the Max, "Enable Better Code Reuse," by Francesco Balena [Visual Studio Magazine, February 2005]

This zip file contains both the VB.NET and C# versions of the code listings that appeared in the magazine, as well as a sample app that demonstrates how to use each of the reflection techniques described in this article.
