Namespace TaxonomyData
    Friend Class BOMessage
        Inherits BaseBO
        Implements IComparable


#Region "Prelim code"
        Public Sub New(ByVal NewBase64Message As String, ByVal NewNumberOfTimesEncoded As Int32)
            Try
                Me.Base64Message = NewBase64Message
                Me.NumberOfTimesBase64Encoded = NewNumberOfTimesEncoded
                Me.Date = System.DateTime.Now
                Me.Status = MessageStatusEnum.Pending
            Catch Ex As Exception
                Throw New Exception("Cannot create new BOMessage object", Ex)
            End Try
        End Sub

        Private Sub New(ByVal Message As DataObjects.Entity.TaxonomyDataLoadMessage)
            InitialiseDO(Message)
        End Sub

        Private Sub InitialiseDO(ByVal Message As DataObjects.Entity.TaxonomyDataLoadMessage)
            If Message Is Nothing Then
                Throw New Exception("Message cannot be nothing")
            Else
                With Message
                    Me.TaxonomyDataLoadMessageID = .Id
                    Me.CheckSum = .CheckSum
                    Me.Date = .Date
                    Me.Message = .Message
                    Me.Diagnostics = .Diagnostics
                    Me.NumberOfTimesBase64Encoded = .NumberOfTimesEncoded
                    Me.DecodeMessage()
                End With
            End If
        End Sub

#End Region

#Region "Properties"
        Public Enum MessageStatusEnum
            Pending = 0
            Loaded = 1
            Rejected = 2
        End Enum

        Public Property Files() As BOFiles
            Get
                Return mFiles
            End Get
            Set(ByVal Value As BOFiles)
                mFiles = Value
            End Set
        End Property
        Private mFiles As BOFiles

        Public Property Status() As MessageStatusEnum
            Get
                Return mStatus
            End Get
            Set(ByVal Value As MessageStatusEnum)
                mStatus = Value
            End Set
        End Property
        Private mStatus As MessageStatusEnum

        Public Property TaxonomyDataLoadMessageID() As Int32
            Get
                Return mTaxonomyDataLoadMessageID
            End Get
            Set(ByVal Value As Int32)
                mTaxonomyDataLoadMessageID = Value
            End Set
        End Property
        Private mTaxonomyDataLoadMessageID As Int32

        Public Property [Date]() As Date
            Get
                Return mDate
            End Get
            Set(ByVal Value As Date)
                mDate = Value
            End Set
        End Property
        Private mDate As Date

        Public Property Base64Message() As String
            Get
                Return mBase64Message
            End Get
            Set(ByVal Value As String)
                mBase64Message = Value
            End Set
        End Property
        Private mBase64Message As String

        Public Property NumberOfTimesBase64Encoded() As Int32
            Get
                Return mNumberOfTimesBase64Encoded
            End Get
            Set(ByVal Value As Int32)
                mNumberOfTimesBase64Encoded = Value
            End Set
        End Property
        Private mNumberOfTimesBase64Encoded As Int32

        Public Property Message() As String
            Get
                Return mMessage
            End Get
            Set(ByVal Value As String)
                mMessage = Value
            End Set
        End Property
        Private mMessage As String

        Public Property Diagnostics() As String
            Get
                Return mDiagnostics
            End Get
            Set(ByVal Value As String)
                mDiagnostics = Value
            End Set
        End Property
        Private mDiagnostics As String

#End Region

#Region "Methods"

        Friend Shared Function LoadPrevious(ByVal TaxonomyDataLoadMessageID As Int32) As BOMessage
            Try
                Dim NewDORequest As New DataObjects.Entity.TaxonomyDataLoadMessage
                Dim service As DataObjects.Service.TaxonomyDataLoadMessageService = NewDORequest.ServiceObject
                Dim DORequest As DataObjects.Entity.TaxonomyDataLoadMessage = service.GetPrevious(TaxonomyDataLoadMessageID)
                If DORequest Is Nothing = False Then
                    Return New BOMessage(DORequest)
                Else
                    Return Nothing
                End If
            Catch ex As Exception
                Throw New Exception("Cannot load previous Taxonomy Data Load Message", ex)
            End Try
        End Function

        Public Function DecodeMessage() As BOFiles
            Try
                Try
                    Me.Files = New BOFiles(Me.Base64Message, Me.NumberOfTimesBase64Encoded)
                Catch ex As Exception
                    Me.Message = "Cannot decode message"
                    Me.Diagnostics = CType(ex, BOException).GetInnerExceptionsMessage
                    Me.Status = MessageStatusEnum.Rejected
                    Me.Save()
                    Return Nothing
                End Try
            Catch ex As Exception
                Throw New Exception("Cannot decode message", ex)
            End Try
        End Function

        Public Overloads Function ScriptLogical() As String
            Try
                Me.Files.ScriptLogical()
            Catch ex As Exception
                Throw New Exception("cannot script logical", ex)
            End Try
        End Function

        Public Overloads Function ScriptPhysical(ByVal PreviousMessage As BOMessage) As String()
            Try
                Me.Files.ScriptPhysical(PreviousMessage.Files)
            Catch ex As Exception
                Throw New Exception("cannot script physical", ex)
            End Try
        End Function

        Public Function FulfillLatestRequest() As BORequest
            Try
                Dim EO As New EnterpriseObjects.Service
                Dim Transaction As System.Data.SqlClient.SqlTransaction = EO.BeginTransaction()
                Try
                    'Get the request.
                    Dim ds As DataSet = [DO].DataObjects.Sprocs.dbo_usp_SelectTaxonomyDataLoadRequestNextToFulfill(Me.Date, Transaction, GetType(DataSet))
                    'Test the request.
                    If ds Is Nothing = False _
                    AndAlso ds.Tables(0).Rows.Count > 0 Then
                        Me.Status = MessageStatusEnum.Pending
                        Me.Save(Transaction)
                        Dim Request As New BORequest(ds)
                        Request.Fulfilled = True
                        Request.Message = "Request fullfilled by message:" & Me.TaxonomyDataLoadMessageID.ToString
                        Request.Save(Transaction)
                        EO.EndTransaction(Transaction, EnterpriseObjects.Service.TransactionEndEnum.Commit)
                        Return Request
                    Else
                        Me.Status = MessageStatusEnum.Rejected
                        Me.Message = "Cannot find a request for this message."
                        Me.Save()
                        Return Nothing
                    End If
                Catch ex As Exception
                    EO.EndTransaction(Transaction, EnterpriseObjects.Service.TransactionEndEnum.Rollback)
                    Throw ex
                End Try
            Catch ex As Exception
                Throw New Exception("Cannot fulfill latest request", ex)
            End Try
        End Function

        Public Function CompareTo(ByVal obj As Object) As Integer Implements System.IComparable.CompareTo
            Try
                If TypeOf obj Is BOMessage Then
                    Dim Message As BOMessage = CType(obj, BOMessage)
                    Return Me.Files.CompareManifest(Message.Files)
                Else
                    Throw New ArgumentException("obj is not a BOMessage object")
                End If
            Catch ex As Exception
                Throw New Exception("cannot compare", ex)
            End Try
        End Function
#End Region

#Region " Save "

        Public Overridable Shadows Function Save(ByVal Transaction As System.Data.SqlClient.SqlTransaction) As BOMessage
            Try
                MyBase.Save()
                Validate()
                Dim NewDOMessage As New DataObjects.Entity.TaxonomyDataLoadMessage
                Dim service As DataObjects.Service.TaxonomyDataLoadMessageService = NewDOMessage.ServiceObject
                If Me.TaxonomyDataLoadMessageID = 0 Then
                    NewDOMessage = service.Insert(MessageStatusEnum.Pending, Me.Date, Me.Base64Message, Me.NumberOfTimesBase64Encoded, Me.Message, Me.Diagnostics, Transaction)
                Else
                    NewDOMessage = service.Update(Me.TaxonomyDataLoadMessageID, Me.Status, Me.Date, Me.Base64Message, Me.NumberOfTimesBase64Encoded, Me.Message, Me.Diagnostics, CheckSum, Transaction)
                End If
                InitialiseDO(NewDOMessage)
                Return Me
            Catch ex As Exception
                Throw New Exception("Cannot save Message", ex)
            End Try
        End Function

        Public Overridable Shadows Function Save() As BOMessage
            Return Me.Save(Nothing)
        End Function

#End Region

#Region " Validate "

        Protected Overridable Overloads Function Validate() As ValidationManager
            Return New ValidationManager
        End Function

#End Region

        
    End Class
End Namespace