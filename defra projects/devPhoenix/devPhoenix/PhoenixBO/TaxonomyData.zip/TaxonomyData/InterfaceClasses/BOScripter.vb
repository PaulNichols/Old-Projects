Namespace TaxonomyData
    Public Class BOScripter
        Inherits BaseBO

#Region "Prelim code"
        Public Sub New(ByVal NewFiles As BOFiles, ByVal OldFiles As BOFiles)
            Try
                mDiagnostics = New ArrayList
                If NewFiles Is Nothing = False Then
                    Me.NewFiles = NewFiles
                Else
                    Throw New Exception("NewFiles is nothing")
                End If
                Me.OldFiles = OldFiles

            Catch ex As Exception
                Throw New Exception("Cannot create new BOScripter object", ex)
            End Try
        End Sub

        Public Sub New(ByVal NewFiles As BOFiles)
            MyClass.New(NewFiles, Nothing)
        End Sub


#End Region

#Region "Properties"

        Private mDiagnostics As ArrayList

        Private Property Started() As Date
            Get
                Return mStarted
            End Get
            Set(ByVal Value As Date)
                mStarted = Value
            End Set
        End Property
        Private mStarted As Date

        Friend Property NewFiles() As BOFiles
            Get
                Return mNewFiles
            End Get
            Set(ByVal Value As BOFiles)
                mNewFiles = Value
            End Set
        End Property
        Private mNewFiles As BOFiles

        Friend Property OldFiles() As BOFiles
            Get
                Return mOldFiles
            End Get
            Set(ByVal Value As BOFiles)
                mOldFiles = Value
            End Set
        End Property
        Private mOldFiles As BOFiles

#End Region

#Region " Methods "

        Private Function HoursTakenSoFar() As String
            Return Me.Started.Subtract(Date.Now).TotalHours.ToString
        End Function

        Friend Function GetDiagnostics() As String
            'Dim sbReport As New Text.StringBuilder
            'With sbReport
            '    .Append("New Files state: " & Me.NewFiles.GetDiagnostics)
            '    If Me.OldFiles Is Nothing = False Then
            '        .Append(" | Old Files state: " & Me.OldFiles.GetDiagnostics)
            '    Else
            '        .Append(" | Old Files state: Object is nothing")
            '    End If
            'End With
        End Function

        Private Function FilesAreDifferent() As Boolean
            'Return Not (Me.NewFiles.Compare(Me.OldFiles) = 0)
        End Function

        Friend Function FilesCanBeUsed() As Boolean
            'Try
            '    If Me.OldFiles Is Nothing = False Then
            '        Return Validates() _
            '        And (Not Me.NewFiles.StatusIsUsed) _
            '        And (Not Me.OldFiles.StatusIsPending)
            '    Else
            '        Return Validates() _
            '        And (Not Me.NewFiles.StatusIsUsed)
            '    End If
            'Catch ex As Exception
            '    Throw New Exception("Cannot determine if files can be used", ex)
            'End Try
        End Function

        Private Sub GenerateReport(ByVal MainReason As String, ByVal ex As Exception)
            mDiagnostics = New ArrayList

        End Sub

        Private Sub GenerateReport(ByVal MainReason As String)
            mDiagnostics = New ArrayList

        End Sub

        Friend Function Script() As Boolean
            Try
                Me.Started = Date.Now
                Dim ContinueScripting As Boolean = False
                'Check if files can be used.
                If Me.FilesCanBeUsed Then
                Else
                    'mCeaseScriptingReasons.Add("The files cannot be used")
                End If

                If Me.FilesAreDifferent = False Then
                End If

                'Me.NewFiles.Get()
                'Me.OldFiles.GetReport()


                'Report back.


            Catch ex As Exception
                Throw New Exception("Cannot script the files", ex)
            End Try
        End Function
#End Region

#Region " Validate "

        Private Function Validates() As Boolean
            Return (Not Validate() Is Nothing) OrElse (Not Me.ValidationErrors.HasErrors)
        End Function

        Protected Overridable Overloads Function Validate() As ValidationManager
            Return New ValidationManager
        End Function

#End Region

    End Class
End Namespace