Imports System.xml
Imports System.xml.Schema
Imports System
Imports System.Collections

Namespace TaxonomyData
    Public Class BOLoad

#Region "Test"
        'TODO: Nick - Remove this code before production.
        Private Function EncodeBase64(ByVal ByteArray As Byte()) As String
            Dim CompressedMessage As String = System.Convert.ToBase64String(ByteArray)
            Return CompressedMessage
        End Function

        Private Function ConvertBase64MessageToByteArray(ByVal Base64Message As String, ByVal NumberOfTimesEncoded As Int32) As System.Byte()
            Try
                Dim MessageByteArray() As System.Byte
                Dim CompressedMessage As String = Base64Message
                If NumberOfTimesEncoded >= 0 Then
                    For Decode As Int32 = 1 To NumberOfTimesEncoded - 1
                        CompressedMessage = DecodeBase64ToString(CompressedMessage)
                    Next
                    MessageByteArray = DecodeBase64toByteArray(CompressedMessage)
                End If
                Return MessageByteArray
            Catch ex As Exception
                Throw New ApplicationException("Cannot convert Base 64 encoded string to system.byte array", ex)
            End Try
        End Function

        Private Function DecodeBase64toByteArray(ByVal Base64 As String) As System.Byte()
            Dim CompressedMessage As String
            Dim CompressedMessageByteArray As System.Byte() = System.Convert.FromBase64String(Base64)
            Return CompressedMessageByteArray
        End Function

        Private Function DecodeBase64ToString(ByVal Base64 As String) As String
            Try
                Dim CompressedMessage As String
                Dim CompressedMessageByteArray As Byte() = System.Convert.FromBase64String(Base64)
                Dim Encoding As System.Text.Encoding = System.Text.Encoding.Default
                CompressedMessage = Encoding.GetString(CompressedMessageByteArray)
                Return CompressedMessage
            Catch ex As Exception
                Throw New Exception("Cannot decode Base 64 encoded string to type string")
            End Try
        End Function



        'TODO: Nick - Remove this before production.
        'Public Overloads Function HandleTaxonomyDataLoadMessage(ByVal Base64Message As String, ByVal NumOfTimesMessageDataIsBase64Encoded As Int32) As String Implements ILoad.HandleTaxonomyDataLoadMessage
        '    '    'Try
        '    '    '    'Load the XML and Schema and validate them.
        '    '    '    Try
        '    '    '        ValidateXMLAgainstSchema(Load("c:\web\XSD\vTaxOrder.xml"), Load("c:\web\xsd\Transfer.xsd"))
        '    '    '    Catch ex As Exception
        '    '    '        Throw New ApplicationException("The supplied XML cannot be validated against the Schemer", ex)
        '    '    '    End Try
        '    '    '    'Get the compressed message contained in the GovTalk XML.
        '    Dim CompressedMessage As String = Base64Message
        '    '    '    Try
        '    Dim MessageByteArray() As Byte
        '    '    '        Dim GovTalkXMLDoc As XmlDocument = New XmlDocument
        '    '    '        GovTalkXMLDoc.LoadXml(XML)
        '    '    '        Dim MessageNode As XmlNodeList = GovTalkXMLDoc.GetElementsByTagName("MessageData")
        '    '    '        If NumOfTimesMessageDataIsBase64Encoded >= 0 Then
        '    '    '            CompressedMessage = MessageNode.Item(0).InnerText
        '    '    '            For Decode As Int32 = 1 To NumOfTimesMessageDataIsBase64Encoded - 1
        '    '    '                CompressedMessage = DecodeBase64ToString(CompressedMessage)
        '    '    '            Next
        '    MessageByteArray = ConvertBase64MessageToByteArray(CompressedMessage, NumOfTimesMessageDataIsBase64Encoded)
        '    '    '        ElseIf IsXML = True Then
        '    '    '            CompressedMessage = MessageNode.Item(0).InnerText
        '    '    '        Else
        '    '    '            MessageByteArray = DecodeBase64toByteArray(XML)
        '    '    '            CompressedMessage = EncodeBase64(MessageByteArray)

        '    '    '        End If
        '    '    '        MessageNode = Nothing
        '    '    '        GovTalkXMLDoc = Nothing
        '    '    '        GC.Collect()
        '    Save(MessageByteArray) 'TODO: Nick - Remove this code before production.
        '    '    '        Save(CompressedMessage) 'TODO: Nick - Remove this code before production.
        '    '    '    Catch ex As Exception
        '    '    '        Throw New ApplicationException("Could not retrieve compressed message data from GovTalk XML", ex)
        '    '    '    End Try
        '    '    'Decompress the message.
        '    '    Try
        '    '        'TODO: Nick - Raise a common code change request to get the decompress to return a sbyte array (and possibly UTF-8 encoding).
        '    '        Dim MessageStringArray() As String = DeCompressToStringArray(DecodeBase64toByteArray(XML))
        '    '    Catch ex As Exception
        '    '        Throw New ApplicationException("Could not decompress message data", ex)
        '    '    End Try

        '    '    'Catch ex As Exception
        '    '    '    Throw New ApplicationException("HandleTaxonomyDataLoadMessage failed", ex)
        '    '    'End Try
        'End Function


        Private Shared reader As XmlValidatingReader = Nothing
        Private Shared treader As XmlTextReader = Nothing
        Private Shared filename As [String] = String.Empty

        Private Overloads Shared Sub ValidateXMLAgainstSchema(ByVal XMLToValidate As String, ByVal ValidatingXSD As String)

            Try
                Dim ReaderXML As XmlValidatingReader = Nothing
                Dim XSD As Xml.Schema.XmlSchema = Nothing
                Dim SchemaCollection As New XmlSchemaCollection

                'Create the XmlParserContext.
                Dim context As New XmlParserContext(Nothing, Nothing, "", XmlSpace.None)
                'Implement the XML reader.
                ReaderXML = New XmlValidatingReader(XMLToValidate, XmlNodeType.Document, context)
                'Implement the XSD reader.
                Dim TheStringReader As New System.io.StringReader(ValidatingXSD)
                Dim TheXMLTextReader As New XmlTextReader(TheStringReader)
                XSD = New Xml.Schema.XmlSchema
                'Add the schema.
                SchemaCollection.Add(XSD.Read(TheXMLTextReader, AddressOf ValidationCallback))
                'Set the schema type and add the schema to the reader.
                ReaderXML.ValidationType = ValidationType.Schema
                ReaderXML.Schemas.Add(SchemaCollection)
                'Add the handler to raise the validation event.
                AddHandler reader.ValidationEventHandler, AddressOf ValidationCallback
                While reader.Read
                End While
            Catch Ex As Exception
                Throw New Exception("Cannot validate XML against schema", Ex)
            End Try
        End Sub

        Private Shared Sub ValidationCallback(ByVal sender As Object, ByVal args As ValidationEventArgs)
            Throw New Exception("Cannot validate XML against schema")
        End Sub

        Public Sub Save(ByVal theData() As Byte)
            Dim theStream As System.IO.FileStream
            Dim theWriter As System.IO.BinaryWriter

            Try
                ' Open a stream
                theStream = New System.IO.FileStream("c:\web\test.zip", IO.FileMode.OpenOrCreate, IO.FileAccess.Write)

                ' Create a writer on the stream
                theWriter = New System.IO.BinaryWriter(theStream)

                theWriter.Write(theData)
                theWriter.Flush()

            Catch ex As Exception

                theData = theData

            Finally

                ' Close our stream and reader

                If Not theStream Is Nothing Then
                    theStream.Close()
                End If

                If Not theWriter Is Nothing Then
                    theWriter.Close()
                End If
            End Try

        End Sub

        Public Sub save(ByVal theData As String)

            ' Create an instance of StreamWriter to write text to a file.
            Dim sw As System.io.StreamWriter = New System.IO.StreamWriter("c:\web\mybase64.txt")
            ' Add some text to the file.
            sw.Write(theData)
            sw.Close()

        End Sub

        Private Function Load(ByVal theFile As String) As String

            Dim theStream As System.IO.FileStream
            Dim theReader As System.IO.BinaryReader
            Dim theData() As Byte
            Dim theString As String

            Try
                ' Open a stream
                theStream = New System.IO.FileStream(theFile, IO.FileMode.Open, IO.FileAccess.Read)

                ' Create a reader on the stream
                theReader = New System.IO.BinaryReader(theStream)

                ' Read in the data
                theData = theReader.ReadBytes(CType(theReader.BaseStream.Length, Integer))

                Dim Encoding As System.Text.Encoding = System.Text.Encoding.UTF8
                theString = Encoding.GetString(theData)

            Catch ex As Exception

                theData = theData

            Finally

                ' Close our stream and reader

                If Not theStream Is Nothing Then
                    theStream.Close()
                End If

                If Not theReader Is Nothing Then
                    theReader.Close()
                End If
            End Try
            Return theString

        End Function

        Public Enum TaxonomyDataLoadRequestStageEnum
            DataRequest = 1
            DataLoad = 2
        End Enum

        Public Enum TaxonomyDataLoadRequestStatusEnum
            Started = 1
            Completed = 2
            Failed = 3
        End Enum


        <Reportable()> _
            Friend Property Stage() As TaxonomyDataLoadRequestStageEnum
            Get
                Return mStage
            End Get
            Set(ByVal Value As TaxonomyDataLoadRequestStageEnum)
                mStage = Value
            End Set
        End Property
        Private mStage As TaxonomyDataLoadRequestStageEnum

        Friend Property Files() As BOFiles
            Get
                Return mFiles
            End Get
            Set(ByVal Value As BOFiles)
                mFiles = Value
            End Set
        End Property
        Private mFiles As BOFiles

        Friend Property Message() As String
            Get
                Return mMessage
            End Get
            Set(ByVal Value As String)
                mMessage = Value
            End Set
        End Property
        Private mMessage As String

        Friend Property Diagnostics() As String
            Get
                Return mDiagnostics
            End Get
            Set(ByVal Value As String)
                mDiagnostics = Value
            End Set
        End Property
        Private mDiagnostics As String

        Friend Property TaxonomyDataLoadDataID() As Int32
            Get
                Return mTaxonomyDataLoadDataID
            End Get
            Set(ByVal Value As Int32)
                mTaxonomyDataLoadDataID = Value
            End Set
        End Property
        Private mTaxonomyDataLoadDataID As Int32

        Friend Sub SetFiles(ByVal Files As BOFiles)
            Try
                Me.Files = Files
            Catch ex As Exception
                Throw New Exception("Cannot set files", ex)
            End Try
        End Sub


        'Friend Shared Function LoadLatest() As BORequest
        '    Try
        '        Dim NewDORequest As New DataObjects.Entity.TaxonomyDataLoadRequest
        '        Dim service As DataObjects.Service.TaxonomyDataLoadRequestService = NewDORequest.ServiceObject
        '        Dim DORequest As DataObjects.Entity.TaxonomyDataLoadRequest = service.GetLatestDataLoadRequest
        '        If DORequest Is Nothing = False Then
        '            Return New BORequest(DORequest)
        '        Else
        '            Return Nothing
        '        End If
        '    Catch ex As Exception
        '        Throw New Exception("Cannot load latest Taxonomy Data Load Request", ex)
        '    End Try
        'End Function

        <AttributeUsage(AttributeTargets.Property)> Public Class Reportable
            Inherits Attribute
        End Class
#End Region
        Public Shared Function HandleRequest() As Boolean
            Try
                Dim NewRequest As New TaxonomyData.BORequest
                NewRequest.Deliver()
            Catch ex As Exception
                Throw New Exception("Cannot handle request", ex)
            End Try

        End Function


        Public Overloads Shared Function HandleTaxonomyDataLoadMessage(ByVal Base64Message As String, ByVal NumberOfTimesEncoded As Int32) As Boolean
            Try
                'Create a new message object based on the received message.
                Dim CurrentMessage As New BOMessage(Base64Message, NumberOfTimesEncoded)
                Dim PreviousMessage As BOMessage = BOMessage.LoadPrevious(CurrentMessage.TaxonomyDataLoadMessageID)
                'Check if there is any other activity.
                If PreviousMessage Is Nothing = False _
                AndAlso PreviousMessage.Status = BOMessage.MessageStatusEnum.Pending Then
                    'The previous message is pending which means that the current message has to remain as pending.
                    CurrentMessage.Message = "A previous message with TaxonomyDataLoadMessageID = " & PreviousMessage.TaxonomyDataLoadMessageID & " is still pending so this message cannot be processed."
                    CurrentMessage.Diagnostics = DateTime.Now.ToString
                    CurrentMessage.Status = BOMessage.MessageStatusEnum.Pending
                    CurrentMessage.Save()
                Else
                    'Asscoiate a request with this message.
                    CurrentMessage.FulfillLatestRequest()

                    If PreviousMessage.Status = BOMessage.MessageStatusEnum.Loaded Then
                        'Check if there are any differences in the current and previous files.
                        If CurrentMessage.CompareTo(PreviousMessage) = 0 Then
                            'The files are the same so there is no need to script the differences.
                            CurrentMessage.Message = "A previous message with TaxonomyDataLoadMessageID = " & PreviousMessage.TaxonomyDataLoadMessageID & " is still pending so this message cannot be processed."
                            CurrentMessage.Diagnostics = DateTime.Now.ToString
                            CurrentMessage.Status = BOMessage.MessageStatusEnum.Rejected
                            CurrentMessage.Save()
                        Else
                            CurrentMessage.ScriptLogical()
                        End If
                    Else
                    End If



                End If






                'Dim DataLoadSuccess As Boolean = False
                'Dim TheseFiles As New BOFiles(Base64Message, NumberOfTimesEncoded)
                'Dim LatestRequest As BORequest = BORequest.LoadLatest
                'Dim PreviousRequest As BORequest = BORequest.LoadPrevious


                ''We have received some data from UNEP-WCMC. Check if we are expecting it.
                'If LatestRequest.Stage = BORequest.TaxonomyDataLoadRequestStageEnum.DataRequest Then
                '    'A data request was sent but check if the data request completed.
                '    If LatestRequest.Status = BORequest.TaxonomyDataLoadRequestStatusEnum.Completed Then
                '        'A data request was sent and completed so handle the new data.
                '        LatestRequest.SetFiles(TheseFiles)
                '        LatestRequest.Save(BORequest.TaxonomyDataLoadRequestStageEnum.DataLoad, _
                '            BORequest.TaxonomyDataLoadRequestStatusEnum.Started, "", "")
                '        'Check that the data load prior to the current one finished.
                '        If PreviousRequest Is Nothing = False Then
                '            If PreviousRequest.Stage = BORequest.TaxonomyDataLoadRequestStageEnum.DataLoad _
                '            AndAlso PreviousRequest.Status <> BORequest.TaxonomyDataLoadRequestStatusEnum.Started Then
                '                'The prior data load did finish so process the data.

                '                Dim RequestScripter As New TaxonomyData.BOScripter
                '            Else
                '                'The prior data load did not finish so terminate this load.
                '                LatestRequest.Save(BORequest.TaxonomyDataLoadRequestStageEnum.DataLoad, _
                '                    BORequest.TaxonomyDataLoadRequestStatusEnum.Failed, _
                '                    "The previous data load is not finished.", _
                '                    "Previous request ID: " & PreviousRequest.TaxonomyDataLoadRequestID.ToString & ", Stage: " & PreviousRequest.Stage.ToString & ", Status: " & PreviousRequest.Status.ToString)
                '            End If
                '        Else 'No previous request exists.
                '            'Process the data.

                '        End If
                '    Else 'Status must be started or failed.
                '        'A data request was not sent or was sent but failed.
                '        LatestRequest.Save(BORequest.TaxonomyDataLoadRequestStageEnum.DataLoad, _
                '            BORequest.TaxonomyDataLoadRequestStatusEnum.Failed, _
                '            "Cannot accept data as the initial request failed or never conpleted.", _
                '            "Stage: " & LatestRequest.Stage.ToString & ", Status: " & LatestRequest.Status.ToString)
                '    End If
                'Else 'Stage must be DataLoad.
                '    'The data load process can only be started in the stage is Request.
                '    LatestRequest.Save(BORequest.TaxonomyDataLoadRequestStageEnum.DataLoad, _
                '        BORequest.TaxonomyDataLoadRequestStatusEnum.Failed, _
                '        "Not expecting any data - load terminated", _
                '        "Stage: " & LatestRequest.Stage.ToString & ", Status: " & LatestRequest.Status.ToString)
                'End If

                ''Check if the previous data load completed.
                ''Create a scripter object.
                ''Dim Scripter As New BOScripter(TheseFiles, OtherFiles)
                ''Scripter.Script()


                ''Load the last good data.
                ''Compare the current data with the last data.
                ''Save the current data.
                ''Build a script containing the differences.
                ''Report back.
                'TheseFiles = Nothing

            Catch ex As Exception
                Throw New Exception("Cannot handle Taxonomy Data Load message", ex)
            End Try

        End Function



    End Class

End Namespace