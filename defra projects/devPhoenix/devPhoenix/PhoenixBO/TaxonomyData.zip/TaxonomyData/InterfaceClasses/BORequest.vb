Namespace TaxonomyData
    Friend Class BORequest
        Inherits BaseBO

#Region "Prelim Code"

        Friend Sub New()
            InitialiseNew()
        End Sub

        Friend Sub New(ByVal Request As DataObjects.Entity.TaxonomyDataLoadRequest)
            InitialiseDO(Request)
        End Sub

        Friend Sub New(ByVal Dataset As DataSet)
            InitialiseDS(DataSet)
        End Sub

        Private Sub InitialiseNew()
        End Sub

        Private Sub InitialiseDO(ByVal Request As DataObjects.Entity.TaxonomyDataLoadRequest)
            If Request Is Nothing Then
                Throw New Exception("Request cannot be nothing")
            Else
                With Request
                    Me.TaxonomyDataLoadRequestID = .Id
                    Me.CheckSum = .CheckSum
                    Me.Date = .Date
                    Me.Fulfilled = .Fulfilled
                    Me.Message = .Message
                End With
            End If
        End Sub

        Private Sub InitialiseDS(ByVal Dataset As DataSet)

            If Dataset.Tables(0).Rows.Count = 1 Then
                With Dataset.Tables(0).Rows(0)
                    Me.TaxonomyDataLoadRequestID = Int32.Parse(.Item("TaxonomyDataLoadRequestID").ToString)
                    Me.CheckSum = Int32.Parse(.Item("CheckSum").ToString)
                    Me.Date = CType(.Item("Date"), System.DateTime)
                    Me.Fulfilled = Boolean.Parse(.Item("Fulfilled").ToString)
                    Me.Message = .Item("Message").ToString
                End With
            Else
                Throw New Exception("Cannot initialise BORequest - invalid dataset")
            End If
        End Sub
#End Region

#Region "Properties"

        Friend Property TaxonomyDataLoadRequestID() As Int32
            Get
                Return mTaxonomyDataLoadRequestID
            End Get
            Set(ByVal Value As Int32)
                mTaxonomyDataLoadRequestID = Value
            End Set
        End Property
        Private mTaxonomyDataLoadRequestID As Int32

        Friend Property Message() As String
            Get
                Return mMessage
            End Get
            Set(ByVal Value As String)
                mMessage = Value
            End Set
        End Property
        Private mMessage As String

        Friend Property Fulfilled() As Boolean
            Get
                Return mFulfilled
            End Get
            Set(ByVal Value As Boolean)
                mFulfilled = Value
            End Set
        End Property
        Private mFulfilled As Boolean

        Friend Property [Date]() As Date
            Get
                Return mDate
            End Get
            Set(ByVal Value As Date)
                mDate = Value
            End Set
        End Property
        Private mDate As Date
#End Region

#Region "Methods"

        Friend Sub Deliver()
            Try
                Me.Save()
                'TODO: Nick - make call to UNEP-WCMC web service to request data.
                'If UNEP-WCMC call success = False Then
                '   Throw New Exception("Request to UNEP-WCMC failed")
                'end if
            Catch ex As Exception
                Throw New Exception("Cannot deliver request", ex)
                
            End Try
        End Sub

        Friend Shared Function GetNextToFulfill(ByVal MessageDate As Date) As BORequest
            Try
                Dim NewDORequest As New DataObjects.Entity.TaxonomyDataLoadRequest


                Dim service As DataObjects.Service.TaxonomyDataLoadRequestService = NewDORequest.ServiceObject
                Dim DORequest As DataObjects.Entity.TaxonomyDataLoadRequest = service.GetNextToFulfill(MessageDate)
                If DORequest Is Nothing = False Then
                    Return New BORequest(DORequest)
                Else
                    Return Nothing
                End If
            Catch ex As Exception
                Throw New Exception("Cannot load the next Taxonomy Data Load Request to be fulfilled", ex)
            End Try
        End Function

#End Region

#Region " Save "

        Friend Overridable Shadows Function Save(ByVal Transaction As System.Data.SqlClient.SqlTransaction) As BORequest
            Try
                MyBase.Save()
                Dim DORequest As New DataObjects.Entity.TaxonomyDataLoadRequest
                Dim service As DataObjects.Service.TaxonomyDataLoadRequestService = DORequest.ServiceObject
                Me.Date = System.DateTime.Now
                If TaxonomyDataLoadRequestID = 0 Then
                    DORequest = service.Insert(Me.Date, False, Me.Message, Transaction)
                Else
                    DORequest = service.Update(Me.TaxonomyDataLoadRequestID, Me.Date, Me.Fulfilled, Me.Message, CheckSum, Transaction)
                End If
                InitialiseDO(DORequest)
                Return Me
            Catch ex As Exception
                Throw New Exception("Cannot save BORequest object", ex)
            End Try
        End Function

        Friend Overridable Shadows Function Save() As BORequest
            Return Me.Save(Nothing)
        End Function

#End Region
    End Class


End Namespace