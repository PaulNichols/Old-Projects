Namespace TaxonomyData
    Public Interface IManifest
        'Property XML() As String
        'Property RowTable() As Manifest.RowDataTable
    End Interface
End Namespace