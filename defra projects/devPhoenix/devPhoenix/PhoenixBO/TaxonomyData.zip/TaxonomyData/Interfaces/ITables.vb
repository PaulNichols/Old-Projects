Namespace TaxonomyData
    Public Interface ITables

    End Interface
End Namespace