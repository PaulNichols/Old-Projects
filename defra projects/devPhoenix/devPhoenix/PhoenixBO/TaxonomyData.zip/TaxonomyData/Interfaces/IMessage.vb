Namespace TaxonomyData
    Public Interface IMessage
        
    End Interface
End Namespace