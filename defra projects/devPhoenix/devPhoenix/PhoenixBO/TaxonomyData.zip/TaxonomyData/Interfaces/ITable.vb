Namespace TaxonomyData
    Public Interface ITable
        
    End Interface
End Namespace